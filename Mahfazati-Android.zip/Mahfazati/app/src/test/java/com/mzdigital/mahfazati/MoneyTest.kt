package com.mzdigital.mahfazati

import com.mzdigital.mahfazati.data.*
import org.junit.Assert.*
import org.junit.Test

class MoneyTest {
    @Test fun parsing() {
        assertEquals(1500L, Money.parse("1.5")); assertEquals(150_000_000L, Money.parse("150,000"))
        assertNull(Money.parse("0")); assertNull(Money.parse("-5")); assertNull(Money.parse("abc"))
    }
    @Test fun transferIsNeutral() {
        val t = listOf(
            Tx(type = "INCOME", amount = 10_000, categoryId = 1, accountId = 1, toAccountId = null, date = 0, note = ""),
            Tx(type = "TRANSFER", amount = 4_000, categoryId = null, accountId = 1, toAccountId = 2, date = 0, note = ""),
            Tx(type = "EXPENSE", amount = 1_000, categoryId = 2, accountId = 2, toAccountId = null, date = 0, note = ""))
        assertEquals(6_000L, balanceOf(1, t)); assertEquals(3_000L, balanceOf(2, t))
        assertEquals(9_000L, balanceOf(1, t) + balanceOf(2, t))
    }
}
