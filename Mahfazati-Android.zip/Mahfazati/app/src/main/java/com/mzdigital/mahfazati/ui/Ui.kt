package com.mzdigital.mahfazati.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.mzdigital.mahfazati.data.*

val Green = Color(0xFF1B9E6B); val Red = Color(0xFFC8372D); val Orange = Color(0xFFE88A17)
private val DEC = KeyboardOptions(keyboardType = KeyboardType.Decimal)
private fun cur(v: Long) = Money.fmt(v) + " د.ع"

@Composable fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Color(0xFF3FCF9F), background = Color(0xFF111614), surface = Color(0xFF111614))
        else lightColorScheme(primary = Color(0xFF0B6B50), secondary = Color(0xFF7BD6B0), background = Color(0xFFF4F6F5)),
        content = content
    )
}

@Composable fun App(vm: VM = viewModel()) {
    val nav = rememberNavController()
    var add by remember { mutableStateOf(false) }
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val main = listOf(
        Triple("home", "الرئيسية", Icons.Default.Home), Triple("tx", "العمليات", Icons.Default.Receipt),
        Triple("budget", "الميزانية", Icons.Default.PieChart), Triple("reports", "التقارير", Icons.Default.BarChart),
        Triple("more", "المزيد", Icons.Default.MoreHoriz)
    )
    Scaffold(
        floatingActionButton = { FloatingActionButton(onClick = { add = true }) { Icon(Icons.Default.Add, "إضافة عملية") } },
        bottomBar = {
            NavigationBar {
                main.forEach { (r, l, i) ->
                    NavigationBarItem(route == r, { nav.navigate(r) { popUpTo("home"); launchSingleTop = true } }, { Icon(i, l) }, label = { Text(l) })
                }
            }
        }
    ) { p ->
        NavHost(nav, "home", Modifier.padding(p)) {
            composable("home") { Home(vm) }
            composable("tx") { Txs(vm) }
            composable("budget") { Budgets(vm) }
            composable("reports") { Reports(vm) }
            composable("more") { More(vm) { nav.navigate(it) } }
            composable("where") { Where(vm) }
            composable("debts") { Debts(vm) }
            composable("accounts") { Accounts(vm) }
        }
    }
    if (add) AddDialog(vm) { add = false }
}

@Composable fun Amt(label: String, text: String, c: Color, m: Modifier = Modifier) =
    Card(m) { Column(Modifier.padding(14.dp)) { Text(label, style = MaterialTheme.typography.labelMedium); Text(text, color = c, style = MaterialTheme.typography.titleMedium) } }

@Composable fun TxRow(t: Tx, cats: List<Category>, onDel: () -> Unit) {
    val c = when (t.type) { "INCOME" -> Green; "EXPENSE" -> Red; else -> Color.Gray }
    ListItem(
        headlineContent = { Text(if (t.type == "TRANSFER") "تحويل" else cats.firstOrNull { it.id == t.categoryId }?.name ?: "—") },
        supportingContent = { Text(Money.date(t.date) + if (t.note.isBlank()) "" else " — " + t.note) },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text((if (t.type == "INCOME") "+" else if (t.type == "EXPENSE") "−" else "") + Money.fmt(t.amount), color = c)
                IconButton(onClick = onDel) { Icon(Icons.Default.Delete, "حذف") }
            }
        }
    )
}

@Composable fun Home(vm: VM) {
    val tx by vm.txs.collectAsStateWithLifecycle(); val accs by vm.accounts.collectAsStateWithLifecycle()
    val cats by vm.cats.collectAsStateWithLifecycle(); val budgets by vm.budgets.collectAsStateWithLifecycle()
    var hide by rememberSaveable { mutableStateOf(false) }
    val ms = Money.monthStart(0); val m = tx.filter { it.date >= ms }
    val inc = m.filter { it.type == "INCOME" }.sumOf { it.amount }; val exp = m.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val total = accs.sumOf { balanceOf(it.id, tx) }
    val cap = budgets.sumOf { it.cap }
    fun s(v: Long) = if (hide) "••••" else cur(v)
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Column(Modifier.padding(20.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("الرصيد الحالي", color = MaterialTheme.colorScheme.onPrimary)
                        IconButton({ hide = !hide }) { Icon(if (hide) Icons.Default.VisibilityOff else Icons.Default.Visibility, "إخفاء الأرصدة", tint = MaterialTheme.colorScheme.onPrimary) }
                    }
                    Text(s(total), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Amt("دخل الشهر", s(inc), Green, Modifier.weight(1f)); Amt("مصروف الشهر", s(exp), Red, Modifier.weight(1f))
            }
        }
        if (cap > 0) item { Amt("المتبقي من ميزانيات الشهر (إجمالي الميزانيات − مصروفاتك)", s(cap - exp), if (cap - exp < 0) Red else Green, Modifier.fillMaxWidth()) }
        item { Text("آخر العمليات", style = MaterialTheme.typography.titleMedium) }
        if (tx.isEmpty()) item { Text("لا توجد عمليات بعد. اضغط + لتسجيل أول عملية.") }
        items(tx.take(8), key = { it.id }) { TxRow(it, cats) { vm.delTx(it) } }
    }
}

@Composable fun Chips(opts: List<Pair<Long, String>>, sel: Long?, onSel: (Long) -> Unit) =
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(opts) { FilterChip(sel == it.first, { onSel(it.first) }, { Text(it.second) }) } }

@Composable fun AddDialog(vm: VM, onClose: () -> Unit) {
    val cats by vm.cats.collectAsStateWithLifecycle(); val accs by vm.accounts.collectAsStateWithLifecycle()
    var type by remember { mutableStateOf("EXPENSE") }; var amt by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<Long?>(null) }; var from by remember { mutableStateOf<Long?>(null) }
    var to by remember { mutableStateOf<Long?>(null) }; var note by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val list = cats.filter { it.income == (type == "INCOME") }
    val accOpts = accs.map { it.id to it.name }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("عملية جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("EXPENSE" to "مصروف", "INCOME" to "دخل", "TRANSFER" to "تحويل").forEach { (k, v) -> FilterChip(type == k, { type = k; cat = null }, { Text(v) }) }
                }
                OutlinedTextField(amt, { amt = it }, label = { Text("المبلغ") }, keyboardOptions = DEC, singleLine = true)
                if (type != "TRANSFER") Chips(list.map { it.id to it.name }, cat) { cat = it }
                Text(if (type == "TRANSFER") "من حساب" else "الحساب")
                Chips(accOpts, from ?: accs.firstOrNull()?.id) { from = it }
                if (type == "TRANSFER") { Text("إلى حساب"); Chips(accOpts, to) { to = it } }
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظة (اختياري)") })
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton({
                val a = Money.parse(amt); val f = from ?: accs.firstOrNull()?.id
                err = when {
                    a == null -> "أدخل مبلغاً صحيحاً أكبر من صفر"
                    f == null -> "لا يوجد حساب"
                    type != "TRANSFER" && cat == null -> "اختر التصنيف"
                    type == "TRANSFER" && (to == null || to == f) -> "اختر حسابين مختلفين"
                    else -> null
                }
                if (err == null) { vm.addTx(Tx(type = type, amount = a!!, categoryId = cat, accountId = f!!, toAccountId = to, date = System.currentTimeMillis(), note = note.trim())); onClose() }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClose) { Text("إلغاء") } }
    )
}

@Composable fun AmountDialog(title: String, max: Long? = null, onOk: (Long) -> Unit, onClose: () -> Unit) {
    var v by remember { mutableStateOf("") }; var e by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) },
        text = { Column { OutlinedTextField(v, { v = it; e = false }, label = { Text("المبلغ") }, keyboardOptions = DEC, singleLine = true, isError = e); if (e) Text("مبلغ غير صالح", color = MaterialTheme.colorScheme.error) } },
        confirmButton = { TextButton({ val a = Money.parse(v); if (a == null || (max != null && a > max)) e = true else { onOk(a); onClose() } }) { Text("حفظ") } },
        dismissButton = { TextButton(onClose) { Text("إلغاء") } }
    )
}

@Composable fun Txs(vm: VM) {
    val tx by vm.txs.collectAsStateWithLifecycle(); val cats by vm.cats.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }; var f by remember { mutableStateOf("ALL") }
    val shown = tx.filter { t ->
        (f == "ALL" || t.type == f) && (q.isBlank() ||
            listOf(t.note, cats.firstOrNull { it.id == t.categoryId }?.name ?: "", Money.fmt(t.amount), Money.plain(t.amount), Money.date(t.date)).any { it.contains(q.trim(), true) })
    }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("بحث: مبلغ، تصنيف، تاريخ، ملاحظة") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("ALL" to "الكل", "INCOME" to "الدخل", "EXPENSE" to "المصروفات").forEach { (k, v) -> FilterChip(f == k, { f = k }, { Text(v) }) }
        }
        if (shown.isEmpty()) Text("لا توجد عمليات مطابقة. اضغط + لإضافة عملية.")
        else LazyColumn { items(shown, key = { it.id }) { TxRow(it, cats) { vm.delTx(it) } } }
    }
}

@Composable fun Budgets(vm: VM) {
    val cats by vm.cats.collectAsStateWithLifecycle(); val budgets by vm.budgets.collectAsStateWithLifecycle(); val tx by vm.txs.collectAsStateWithLifecycle()
    var edit by remember { mutableStateOf<Category?>(null) }
    val spent = spentByCat(tx, 0)
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("ميزانيات الشهر الحالي — اضغط على تصنيف لتحديد ميزانيته", style = MaterialTheme.typography.titleMedium) }
        items(cats.filter { !it.income }) { c ->
            val cap = budgets.firstOrNull { it.categoryId == c.id }?.cap; val used = spent[c.id] ?: 0L
            Card(Modifier.fillMaxWidth().clickable { edit = c }) {
                Column(Modifier.padding(14.dp)) {
                    Text(c.name, style = MaterialTheme.typography.titleSmall)
                    if (cap == null) Text("لم تُحدد ميزانية بعد") else {
                        val r = used.toDouble() / cap
                        LinearProgressIndicator(progress = { r.toFloat().coerceIn(0f, 1f) }, color = if (r >= 0.7) (if (r >= 1) Red else Orange) else Green, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                        Text("المحدد ${Money.fmt(cap)} · المستهلك ${Money.fmt(used)} · المتبقي ${Money.fmt(cap - used)} · ${(r * 100).toInt()}%")
                        if (r >= 1) Text("تجاوزت الميزانية", color = Red) else if (r >= 0.9) Text("تنبيه: استهلكت 90% من الميزانية", color = Orange) else if (r >= 0.7) Text("تنبيه: استهلكت 70% من الميزانية", color = Orange)
                    }
                }
            }
        }
    }
    edit?.let { c -> AmountDialog("ميزانية ${c.name} الشهرية", null, { vm.setBudget(c.id, it) }) { edit = null } }
}

@Composable fun Where(vm: VM) {
    val tx by vm.txs.collectAsStateWithLifecycle(); val cats by vm.cats.collectAsStateWithLifecycle()
    val cur = spentByCat(tx, 0); val prev = spentByCat(tx, -1)
    val total = cur.values.sum(); val prevTotal = prev.values.sum()
    fun nm(id: Long) = cats.firstOrNull { it.id == id }?.name ?: "—"
    val top = cur.entries.sortedByDescending { it.value }.take(3)
    val notes = mutableListOf<String>()
    if (total > 0) {
        notes += "«${nm(top[0].key)}» يستهلك ${top[0].value * 100 / total}% من مصروفاتك هذا الشهر."
        top.forEach { e ->
            val p = prev[e.key] ?: 0L
            if (p > 0 && e.value > p) notes += "مصروفات «${nm(e.key)}» ارتفعت ${(e.value - p) * 100 / p}% عن الشهر الماضي؛ لو بقيت كما كانت لوفّرت ${Money.fmt(e.value - p)} د.ع."
        }
        notes += if (prevTotal > 0) "إجمالي مصروفاتك ${if (total > prevTotal) "أعلى" else "أقل"} من الشهر الماضي (${Money.fmt(prevTotal)} د.ع)." else "لا توجد مصروفات مسجلة في الشهر الماضي للمقارنة."
    }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (total == 0L) item { Text("لا توجد مصروفات مسجلة هذا الشهر بعد. سجّل مصروفاً وسيظهر التحليل هنا.") }
        else {
            item { Text("أنفقت هذا الشهر ${cur(total)}", style = MaterialTheme.typography.headlineSmall) }
            item { Text("أكثر ثلاثة أبواب استهلاكاً:", style = MaterialTheme.typography.titleMedium) }
            items(top.size) { i -> Text("${i + 1}. ${nm(top[i].key)}: ${cur(top[i].value)} (${top[i].value * 100 / total}%)") }
            item { Text("التحليل", style = MaterialTheme.typography.titleMedium) }
            items(notes) { Card(Modifier.fillMaxWidth()) { Text(it, Modifier.padding(12.dp)) } }
        }
    }
}

@Composable fun Debts(vm: VM) {
    val ds by vm.debts.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }; var add by remember { mutableStateOf(false) }; var pay by remember { mutableStateOf<Debt?>(null) }
    val mine = tab == 0
    Scaffold(floatingActionButton = { FloatingActionButton({ add = true }) { Icon(Icons.Default.Add, "إضافة دين") } }) { p ->
        Column(Modifier.padding(p)) {
            TabRow(tab) { Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("ديون لي") }); Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("ديون عليّ") }) }
            val list = ds.filter { it.owedToMe == mine }
            if (list.isEmpty()) Text("لا توجد ديون هنا. اضغط + لإضافة دين.", Modifier.padding(16.dp))
            LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.id }) { d ->
                    val rem = d.total - d.paid
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("${d.person} — ${if (rem == 0L) "مسدد" else if (d.paid > 0) "سداد جزئي" else "غير مسدد"}", style = MaterialTheme.typography.titleSmall)
                            Text("الإجمالي ${Money.fmt(d.total)} · المسدد ${Money.fmt(d.paid)} · المتبقي ${Money.fmt(rem)}")
                            Text("التاريخ ${Money.date(d.date)}" + (d.due?.let { " · الاستحقاق ${Money.date(it)}" } ?: ""))
                            if (d.note.isNotBlank()) Text(d.note)
                            Row { if (rem > 0) TextButton({ pay = d }) { Text("تسجيل سداد") }; TextButton({ vm.delDebt(d) }) { Text("حذف") } }
                        }
                    }
                }
            }
        }
    }
    pay?.let { d -> AmountDialog("سداد ${d.person} (حتى ${Money.fmt(d.total - d.paid)})", d.total - d.paid, { vm.pay(d, it) }) { pay = null } }
    if (add) DebtDialog(mine, vm) { add = false }
}

@Composable fun DebtDialog(mine: Boolean, vm: VM, onClose: () -> Unit) {
    var p by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }; var due by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }; var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose, title = { Text(if (mine) "دين لي" else "دين عليّ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(p, { p = it }, label = { Text("اسم الشخص") }, singleLine = true)
                OutlinedTextField(a, { a = it }, label = { Text("المبلغ") }, keyboardOptions = DEC, singleLine = true)
                OutlinedTextField(due, { due = it }, label = { Text("الاستحقاق yyyy-MM-dd (اختياري)") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") })
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton({
                val m = Money.parse(a); val d = if (due.isBlank()) null else Money.parseDate(due)
                err = when { p.isBlank() -> "أدخل اسم الشخص"; m == null -> "أدخل مبلغاً صحيحاً"; due.isNotBlank() && d == null -> "تاريخ غير صالح"; else -> null }
                if (err == null) { vm.addDebt(Debt(person = p.trim(), total = m!!, owedToMe = mine, date = System.currentTimeMillis(), due = d, note = note.trim())); onClose() }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClose) { Text("إلغاء") } }
    )
}

@Composable fun Accounts(vm: VM) {
    val accs by vm.accounts.collectAsStateWithLifecycle(); val tx by vm.txs.collectAsStateWithLifecycle()
    var add by remember { mutableStateOf(false) }; var n by remember { mutableStateOf("") }
    Scaffold(floatingActionButton = { FloatingActionButton({ add = true }) { Icon(Icons.Default.Add, "إضافة حساب") } }) { p ->
        LazyColumn(Modifier.padding(p)) { items(accs) { ListItem(headlineContent = { Text(it.name) }, trailingContent = { Text(cur(balanceOf(it.id, tx))) }) } }
    }
    if (add) AlertDialog(
        onDismissRequest = { add = false }, title = { Text("حساب جديد (نقداً، مصرف، محفظة...)") },
        text = { OutlinedTextField(n, { n = it }, label = { Text("اسم الحساب") }, singleLine = true) },
        confirmButton = { TextButton({ if (n.isNotBlank()) { vm.addAccount(n.trim()); n = ""; add = false } }) { Text("حفظ") } },
        dismissButton = { TextButton({ add = false }) { Text("إلغاء") } }
    )
}

@Composable fun Reports(vm: VM) {
    val tx by vm.txs.collectAsStateWithLifecycle(); val cats by vm.cats.collectAsStateWithLifecycle()
    val months = (-5..0).map { o -> o to tx.filter { it.date >= Money.monthStart(o) && it.date < Money.monthStart(o + 1) } }
    val sums = months.map { (_, l) -> l.filter { it.type == "INCOME" }.sumOf { it.amount } to l.filter { it.type == "EXPENSE" }.sumOf { it.amount } }
    val mx = maxOf(1L, sums.maxOf { maxOf(it.first, it.second) })
    val byCat = spentByCat(tx, 0).entries.sortedByDescending { it.value }; val tot = byCat.sumOf { it.value }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("الدخل والمصروفات — آخر ٦ أشهر", style = MaterialTheme.typography.titleMedium) }
        items(months.size) { i ->
            val (inc, exp) = sums[i]
            Column {
                Text(Money.date(Money.monthStart(months[i].first)).take(7) + "  ·  صافي ${Money.fmt(inc - exp)}")
                Box(Modifier.fillMaxWidth(inc.toFloat() / mx).height(10.dp).background(Green))
                Spacer(Modifier.height(3.dp))
                Box(Modifier.fillMaxWidth(exp.toFloat() / mx).height(10.dp).background(Red))
            }
        }
        item { Text("المصروفات حسب التصنيف هذا الشهر", style = MaterialTheme.typography.titleMedium) }
        if (byCat.isEmpty()) item { Text("لا توجد مصروفات هذا الشهر.") }
        items(byCat) { e ->
            Column {
                Text("${cats.firstOrNull { it.id == e.key }?.name ?: "—"}: ${cur(e.value)} (${e.value * 100 / tot}%)")
                LinearProgressIndicator(progress = { e.value.toFloat() / tot }, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable fun More(vm: VM, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val tx by vm.txs.collectAsStateWithLifecycle(); val cats by vm.cats.collectAsStateWithLifecycle(); val accs by vm.accounts.collectAsStateWithLifecycle()
    var about by remember { mutableStateOf(false) }; var wipe by remember { mutableStateOf(false) }
    fun export() {
        val sb = StringBuilder("date,type,amount,category,account,note\n")
        tx.forEach { t ->
            val c = cats.firstOrNull { it.id == t.categoryId }?.name ?: ""; val a = accs.firstOrNull { it.id == t.accountId }?.name ?: ""
            sb.append("${Money.date(t.date)},${t.type},${Money.plain(t.amount)},\"$c\",\"$a\",\"${t.note.replace("\"", "\"\"")}\"\n")
        }
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/csv"; putExtra(Intent.EXTRA_TEXT, sb.toString()) }, "تصدير CSV"))
    }
    Column(Modifier.padding(8.dp)) {
        listOf("أين اختفت أموالي؟" to { go("where") }, "الديون" to { go("debts") }, "الحسابات والمحافظ" to { go("accounts") },
            "تصدير العمليات CSV" to { export() }, "حول التطبيق" to { about = true }, "حذف كل البيانات" to { wipe = true }).forEach { (t, a) ->
            ListItem(headlineContent = { Text(t) }, modifier = Modifier.clickable { a() })
        }
    }
    if (about) AlertDialog({ about = false }, confirmButton = { TextButton({ about = false }) { Text("إغلاق") } },
        title = { Text("Mahfazati | محفظتي") }, text = { Text("Developed by M.Z DIGITAL\n\n© 2026 M.Z DIGITAL. All Rights Reserved.") })
    if (wipe) AlertDialog({ wipe = false }, title = { Text("حذف كل البيانات؟") }, text = { Text("سيتم حذف كل العمليات والديون والميزانيات نهائياً.") },
        confirmButton = { TextButton({ vm.wipe(); wipe = false }) { Text("حذف", color = Red) } }, dismissButton = { TextButton({ wipe = false }) { Text("إلغاء") } })
}
