package com.mzdigital.mahfazati

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.mzdigital.mahfazati.ui.App
import com.mzdigital.mahfazati.ui.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() } }
        }
    }
}
