package com.mzdigital.mahfazati.data

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.*

/** All amounts are stored as Long in thousandths of the currency unit (exact, no floating point). */
@Entity data class Account(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val currency: String = "IQD")
@Entity data class Category(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val income: Boolean)
@Entity data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, val type: String, val amount: Long,
    val categoryId: Long?, val accountId: Long, val toAccountId: Long?, val date: Long, val note: String
)
@Entity data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, val person: String, val total: Long, val paid: Long = 0,
    val owedToMe: Boolean, val date: Long, val due: Long?, val note: String
)
@Entity data class Budget(@PrimaryKey val categoryId: Long, val cap: Long)

@Dao interface FinDao {
    @Query("SELECT * FROM Account") fun accounts(): Flow<List<Account>>
    @Query("SELECT * FROM Category") fun categories(): Flow<List<Category>>
    @Query("SELECT * FROM Tx ORDER BY date DESC, id DESC") fun txs(): Flow<List<Tx>>
    @Query("SELECT * FROM Debt ORDER BY id DESC") fun debts(): Flow<List<Debt>>
    @Query("SELECT * FROM Budget") fun budgets(): Flow<List<Budget>>
    @Insert suspend fun addAccount(a: Account): Long
    @Insert suspend fun addCategory(c: Category): Long
    @Insert suspend fun addTx(t: Tx)
    @Insert suspend fun addDebt(d: Debt)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putBudget(b: Budget)
    @Update suspend fun updateDebt(d: Debt)
    @Delete suspend fun delTx(t: Tx)
    @Delete suspend fun delDebt(d: Debt)
    @Query("SELECT COUNT(*) FROM Category") suspend fun catCount(): Int
    @Query("SELECT COUNT(*) FROM Account") suspend fun accCount(): Int
}

@Database(entities = [Account::class, Category::class, Tx::class, Debt::class, Budget::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): FinDao
    companion object {
        @Volatile private var I: Db? = null
        fun get(c: Context): Db = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "mahfazati.db").build().also { I = it }
        }
    }
}

object Money {
    fun parse(s: String): Long? {
        val v = s.trim().replace(",", "").toBigDecimalOrNull() ?: return null
        if (v.signum() <= 0) return null
        return v.movePointRight(3).setScale(0, RoundingMode.HALF_UP).toLong()
    }
    fun fmt(v: Long): String = DecimalFormat("#,##0.##", DecimalFormatSymbols(Locale.US)).format(BigDecimal(v).movePointLeft(3))
    fun plain(v: Long): String = BigDecimal(v).movePointLeft(3).stripTrailingZeros().toPlainString()
    fun date(t: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))
    fun parseDate(s: String): Long? =
        runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(s.trim())!!.time }.getOrNull()
    fun monthStart(off: Int): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, off)
    }.timeInMillis
}

/** Transfers move money between accounts and are never counted as income or expense. */
fun balanceOf(id: Long, tx: List<Tx>): Long = tx.sumOf {
    when {
        it.type == "INCOME" && it.accountId == id -> it.amount
        it.type == "EXPENSE" && it.accountId == id -> -it.amount
        it.type == "TRANSFER" && it.accountId == id -> -it.amount
        it.type == "TRANSFER" && it.toAccountId == id -> it.amount
        else -> 0L
    }
}

fun spentByCat(tx: List<Tx>, off: Int): Map<Long, Long> {
    val a = Money.monthStart(off); val b = Money.monthStart(off + 1)
    return tx.filter { it.type == "EXPENSE" && it.date >= a && it.date < b && it.categoryId != null }
        .groupBy { it.categoryId!! }.mapValues { e -> e.value.sumOf { it.amount } }
}

class VM(app: Application) : AndroidViewModel(app) {
    private val d = Db.get(app).dao()
    private fun <T> Flow<T>.st(init: T) = stateIn(viewModelScope, SharingStarted.Eagerly, init)
    val accounts = d.accounts().st(emptyList())
    val cats = d.categories().st(emptyList())
    val txs = d.txs().st(emptyList())
    val debts = d.debts().st(emptyList())
    val budgets = d.budgets().st(emptyList())

    init { viewModelScope.launch { seed() } }

    private suspend fun seed() {
        if (d.catCount() == 0) {
            listOf("الطعام والشراب", "النقل والمواصلات", "التسوق", "الفواتير", "الإنترنت والاتصالات", "الصحة", "التعليم", "المنزل", "الترفيه", "أخرى")
                .forEach { d.addCategory(Category(name = it, income = false)) }
            listOf("الراتب", "العمل الإضافي", "التجارة", "الهدايا", "المشاريع", "أخرى")
                .forEach { d.addCategory(Category(name = it, income = true)) }
        }
        if (d.accCount() == 0) d.addAccount(Account(name = "نقداً"))
    }

    fun addTx(t: Tx) { viewModelScope.launch { d.addTx(t) } }
    fun delTx(t: Tx) { viewModelScope.launch { d.delTx(t) } }
    fun addDebt(x: Debt) { viewModelScope.launch { d.addDebt(x) } }
    fun delDebt(x: Debt) { viewModelScope.launch { d.delDebt(x) } }
    fun pay(x: Debt, amount: Long) { viewModelScope.launch { d.updateDebt(x.copy(paid = minOf(x.total, x.paid + amount))) } }
    fun setBudget(catId: Long, cap: Long) { viewModelScope.launch { d.putBudget(Budget(catId, cap)) } }
    fun addAccount(name: String) { viewModelScope.launch { d.addAccount(Account(name = name)) } }
    fun wipe() { viewModelScope.launch(Dispatchers.IO) { Db.get(getApplication()).clearAllTables(); seed() } }
}
