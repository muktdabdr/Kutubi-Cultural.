package com.kutubi.cultural.ui.reader

import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kutubi.cultural.data.Book
import com.kutubi.cultural.data.Bookmark
import com.kutubi.cultural.data.Highlight
import com.kutubi.cultural.pdf.ReaderSession
import com.kutubi.cultural.pdf.SearchHit
import com.kutubi.cultural.ui.AppViewModel
import com.kutubi.cultural.ui.common.NoteDialog
import com.kutubi.cultural.ui.theme.Brown
import com.kutubi.cultural.ui.theme.Gold
import com.kutubi.cultural.ui.theme.Ivory
import com.kutubi.cultural.util.findActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

private enum class Sheet { None, Index, Search, Settings }

@Composable
fun ReaderScreen(vm: AppViewModel, bookId: Long, startPage: Int, focusHl: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val book = remember(bookId) { vm.books.value.firstOrNull { it.id == bookId } }
    if (book == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val allHl by vm.highlights.collectAsState()
    val allBm by vm.bookmarks.collectAsState()
    val hls = remember(allHl, bookId) { allHl.filter { it.bookId == bookId } }
    val bms = remember(allBm, bookId) { allBm.filter { it.bookId == bookId } }

    var session by remember { mutableStateOf<ReaderSession?>(null) }
    var sizesReady by remember { mutableStateOf(false) }
    var hasText by remember { mutableStateOf<Boolean?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(bookId) {
        try {
            val s = withContext(Dispatchers.IO) { ReaderSession(File(book.path)) }
            session = s
            s.loadSizes()
            sizesReady = true
            hasText = s.detectText()
        } catch (e: Exception) {
            error = "تعذّر فتح هذا الكتاب. قد يكون الملف تالفاً."
        }
    }
    DisposableEffect(bookId) {
        onDispose { session?.close() }
    }

    // السطوع وإبقاء الشاشة مضيئة أثناء القراءة
    val activity = ctx.findActivity()
    val brightness = vm.settings.brightness
    LaunchedEffect(brightness) {
        activity?.window?.let { w ->
            val lp = w.attributes
            lp.screenBrightness = if (brightness < 0f) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else brightness
            w.attributes = lp
        }
    }
    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.let { w ->
                w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = lp
            }
        }
    }

    val bg = when (vm.settings.readerMode) {
        1 -> Color(0xFF0E0E0E)
        2 -> Color(0xFFE6D8B5)
        else -> Color(0xFFE9E9E9)
    }
    Box(Modifier.fillMaxSize().background(bg)) {
        val s = session
        val err = error
        when {
            err != null -> Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(err, color = Brown)
                TextButton(onClick = onBack) { Text("رجوع") }
            }
            s == null || !sizesReady -> Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Gold)
                Text("جارٍ تجهيز الكتاب…", Modifier.padding(top = 12.dp), color = Brown)
            }
            else -> ReaderBody(vm, book, s, hasText, startPage, focusHl, hls, bms, onBack)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
private fun ReaderBody(
    vm: AppViewModel,
    book: Book,
    session: ReaderSession,
    hasText: Boolean?,
    startPage: Int,
    focusHl: Long,
    hls: List<Highlight>,
    bms: List<Bookmark>,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val pages = session.pageCount
    val initial = (if (startPage >= 0) startPage else book.lastPage).coerceIn(0, pages - 1)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = initial)
    val mode = vm.settings.readerMode

    var zoom by remember { mutableFloatStateOf(1f) }
    var controls by remember { mutableStateOf(true) }
    var sel by remember { mutableStateOf<Sel?>(null) }
    var activeHl by remember { mutableStateOf<Long?>(if (focusHl >= 0) focusHl else null) }
    var mark by remember { mutableStateOf<Sel?>(null) }
    var sheet by remember { mutableStateOf(Sheet.None) }
    var noteFor by remember { mutableStateOf<Long?>(null) }
    var goTo by remember { mutableStateOf(false) }
    var goToText by remember { mutableStateOf("") }
    var banner by remember { mutableStateOf(true) }

    // البحث
    var query by remember { mutableStateOf("") }
    val results = remember { mutableStateListOf<SearchHit>() }
    var searching by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var searchJob by remember { mutableStateOf<Job?>(null) }

    val current by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val mid = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.firstOrNull { it.offset <= mid && it.offset + it.size > mid }?.index
                ?: listState.firstVisibleItemIndex
        }
    }
    val activeH = activeHl?.let { id -> hls.firstOrNull { it.id == id } }
    val bookmarkHere = bms.firstOrNull { it.page == current }

    LaunchedEffect(Unit) {
        snapshotFlow { current }.collectLatest { p ->
            delay(300)
            vm.saveProgress(book.id, p)
        }
    }
    DisposableEffect(Unit) {
        onDispose { vm.saveProgress(book.id, current) }
    }

    fun goPage(p: Int) {
        scope.launch { listState.scrollToItem(p.coerceIn(0, pages - 1)) }
    }

    fun clearAll() { sel = null; activeHl = null }

    fun startSearch() {
        searchJob?.cancel()
        results.clear()
        val q = query
        if (q.isBlank()) return
        progress = 0
        searching = true
        searchJob = scope.launch {
            try {
                session.search(q, { progress = it }, { results.add(it) })
            } catch (e: Exception) {
            } finally {
                searching = false
            }
        }
    }

    fun pickColor(c: Int) {
        val a = activeH
        val s = sel
        if (a != null) {
            vm.setColor(a.id, c)
        } else if (s != null) {
            scope.launch {
                val pt = session.pageText(s.page)
                val id = vm.createHighlight(book.id, s.page, s.start, s.end, pt.textOf(s.start, s.end), c)
                sel = null
                activeHl = id
            }
        }
    }

    fun openNote() {
        val a = activeH
        val s = sel
        if (a != null) {
            noteFor = a.id
        } else if (s != null) {
            scope.launch {
                val pt = session.pageText(s.page)
                val id = vm.createHighlight(book.id, s.page, s.start, s.end, pt.textOf(s.start, s.end), 0)
                sel = null
                activeHl = id
                noteFor = id
            }
        }
    }

    fun copyText() {
        val a = activeH
        val s = sel
        scope.launch {
            val t = when {
                a != null -> a.text
                s != null -> session.pageText(s.page).textOf(s.start, s.end)
                else -> ""
            }
            if (t.isNotEmpty()) {
                clipboard.setText(AnnotatedString(t))
                Toast.makeText(ctx, "تم نسخ النص", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler(enabled = sel != null || activeHl != null) { clearAll() }

    Box(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val pageWidth = maxWidth
            Row(Modifier.fillMaxHeight().horizontalScroll(rememberScrollState())) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.width(pageWidth * zoom).fillMaxHeight(),
                    contentPadding = PaddingValues(top = 72.dp, bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(count = pages, key = { it }) { i ->
                        PdfPageItem(
                            index = i,
                            session = session,
                            textEnabled = hasText == true,
                            mode = mode,
                            highlights = hls,
                            sel = sel,
                            mark = mark,
                            activeId = activeHl,
                            onSelect = { sel = it; activeHl = null; mark = null },
                            onHighlightTap = { activeHl = it; sel = null },
                            onBlankTap = {
                                if (sel != null || activeHl != null) clearAll()
                                else { mark = null; controls = !controls }
                            },
                            onDoubleTap = { zoom = if (zoom < 1.5f) 2f else 1f }
                        )
                    }
                }
            }
        }

        // الشريط العلوي
        AnimatedVisibility(
            visible = controls,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            Surface(color = Brown, contentColor = Ivory, shadowElevation = 4.dp) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Ivory) }
                        Text(
                            book.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium, color = Ivory
                        )
                        IconButton(onClick = {
                            if (bookmarkHere != null) vm.deleteBookmark(bookmarkHere.id)
                            else {
                                vm.addBookmark(book.id, current)
                                Toast.makeText(ctx, "تمت إضافة إشارة مرجعية", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(
                                if (bookmarkHere != null) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                "إشارة مرجعية", tint = if (bookmarkHere != null) Gold else Ivory
                            )
                        }
                        IconButton(onClick = { sheet = Sheet.Search }) { Icon(Icons.Filled.Search, "بحث", tint = Ivory) }
                        IconButton(onClick = { sheet = Sheet.Index }) { Icon(Icons.Filled.FormatListBulleted, "الفهرس", tint = Ivory) }
                        IconButton(onClick = { sheet = Sheet.Settings }) { Icon(Icons.Filled.Tune, "إعدادات القراءة", tint = Ivory) }
                    }
                    if (hasText == false && banner) {
                        Row(
                            Modifier.fillMaxWidth().background(Gold).padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "هذا الملف مصوّر ولا يحتوي على نص قابل للتحديد، لذلك تحديد النص والتظليل والبحث غير متاحة فيه.",
                                Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = Color(0xFF3E2618)
                            )
                            TextButton(onClick = { banner = false }) { Text("حسناً", color = Color(0xFF3E2618)) }
                        }
                    }
                }
            }
        }

        // الشريط السفلي
        Column(Modifier.align(Alignment.BottomCenter)) {
            if (sel != null || activeH != null) {
                SelectionBar(
                    activeColor = activeH?.color,
                    note = activeH?.note,
                    onColor = { pickColor(it) },
                    onNote = { openNote() },
                    onCopy = { copyText() },
                    onDelete = if (activeH != null) ({ vm.deleteHighlight(activeH.id); activeHl = null }) else null,
                    onClose = { clearAll() }
                )
            }
            AnimatedVisibility(
                visible = controls,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it }
            ) {
                Surface(color = Brown, contentColor = Ivory) {
                    Column(Modifier.fillMaxWidth()) {
                        if (pages > 1) {
                            Slider(
                                value = current.toFloat(),
                                onValueChange = { goPage(it.roundToInt()) },
                                valueRange = 0f..(pages - 1).toFloat(),
                                modifier = Modifier.padding(horizontal = 16.dp),
                                colors = SliderDefaults.colors(
                                    thumbColor = Gold, activeTrackColor = Gold,
                                    inactiveTrackColor = Ivory.copy(alpha = 0.3f)
                                )
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 4.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { zoom = (zoom - 0.25f).coerceAtLeast(1f) }) {
                                Icon(Icons.Filled.ZoomOut, "تصغير", tint = Ivory)
                            }
                            Surface(
                                shape = RoundedCornerShape(20.dp), color = Ivory.copy(alpha = 0.15f),
                                modifier = Modifier.clickable { goToText = ""; goTo = true }
                            ) {
                                Text(
                                    "${current + 1} / $pages",
                                    Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = Ivory
                                )
                            }
                            IconButton(onClick = { zoom = (zoom + 0.25f).coerceAtMost(3f) }) {
                                Icon(Icons.Filled.ZoomIn, "تكبير", tint = Ivory)
                            }
                        }
                    }
                }
            }
        }
    }

    // الانتقال إلى صفحة
    if (goTo) {
        AlertDialog(
            onDismissRequest = { goTo = false },
            containerColor = Ivory,
            title = { Text("الانتقال إلى صفحة") },
            text = {
                OutlinedTextField(
                    value = goToText, onValueChange = { goToText = it.filter { c -> c.isDigit() }.take(6) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("1 – $pages") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = goToText.toIntOrNull()
                    if (n != null) goPage(n - 1)
                    goTo = false
                }) { Text("انتقال") }
            },
            dismissButton = { TextButton(onClick = { goTo = false }) { Text("إلغاء") } }
        )
    }

    // الملاحظة
    val nf = noteFor
    if (nf != null) {
        val h = hls.firstOrNull { it.id == nf }
        if (h != null) {
            NoteDialog(h.text, h.note, onSave = { vm.setNote(h.id, it); noteFor = null }, onDismiss = { noteFor = null })
        }
    }

    // اللوحات السفلية
    if (sheet != Sheet.None) {
        ModalBottomSheet(onDismissRequest = { sheet = Sheet.None }, containerColor = Ivory) {
            when (sheet) {
                Sheet.Index -> IndexSheet(
                    session = session, bookmarks = bms,
                    onGo = { goPage(it); sheet = Sheet.None },
                    onDeleteBookmark = { vm.deleteBookmark(it) }
                )
                Sheet.Search -> SearchSheet(
                    textAvailable = hasText,
                    query = query, onQuery = { query = it },
                    searching = searching, progress = progress, total = pages,
                    results = results,
                    onSearch = { startSearch() },
                    onPick = { r ->
                        mark = Sel(r.page, r.start, r.end)
                        sel = null; activeHl = null
                        goPage(r.page)
                        sheet = Sheet.None
                    }
                )
                Sheet.Settings -> ReaderSettingsSheet(
                    mode = mode, onMode = { vm.settings.updateMode(it) },
                    brightness = vm.settings.brightness, onBrightness = { vm.settings.updateBrightness(it) },
                    onResetZoom = { zoom = 1f }
                )
                Sheet.None -> {}
            }
        }
    }
}
