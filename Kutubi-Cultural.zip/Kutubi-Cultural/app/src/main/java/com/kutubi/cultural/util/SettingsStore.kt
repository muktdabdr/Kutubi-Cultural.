package com.kutubi.cultural.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** إعدادات القراءة: 0 نهاري، 1 ليلي، 2 ورقي. السطوع: -1 = سطوع النظام. */
class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var readerMode by mutableIntStateOf(p.getInt("mode", 2))
        private set
    var brightness by mutableFloatStateOf(p.getFloat("brightness", -1f))
        private set

    fun updateMode(m: Int) {
        readerMode = m
        p.edit().putInt("mode", m).apply()
    }

    fun updateBrightness(b: Float) {
        brightness = b
        p.edit().putFloat("brightness", b).apply()
    }
}
