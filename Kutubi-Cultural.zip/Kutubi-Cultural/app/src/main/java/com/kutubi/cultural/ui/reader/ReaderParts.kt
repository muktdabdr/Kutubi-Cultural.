package com.kutubi.cultural.ui.reader

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kutubi.cultural.data.Bookmark
import com.kutubi.cultural.data.HlColors
import com.kutubi.cultural.pdf.OutlineEntry
import com.kutubi.cultural.pdf.ReaderSession
import com.kutubi.cultural.pdf.SearchHit
import com.kutubi.cultural.ui.theme.Brown
import com.kutubi.cultural.ui.theme.DarkBrown
import com.kutubi.cultural.ui.theme.Gold
import com.kutubi.cultural.ui.theme.Ivory
import com.kutubi.cultural.ui.theme.Parchment
import com.kutubi.cultural.util.formatDate

@Composable
fun SelectionBar(
    activeColor: Int?,
    note: String?,
    onColor: (Int) -> Unit,
    onNote: () -> Unit,
    onCopy: () -> Unit,
    onDelete: (() -> Unit)?,
    onClose: () -> Unit
) {
    Surface(color = Ivory, shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            if (!note.isNullOrBlank()) {
                Text(
                    note, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = Brown,
                    modifier = Modifier.clickable(onClick = onNote).padding(bottom = 6.dp)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                for (i in 0 until 4) {
                    Box(
                        Modifier.padding(end = 10.dp).size(34.dp)
                            .clip(CircleShape).background(HlColors.argb[i])
                            .border(if (activeColor == i) 3.dp else 1.dp, if (activeColor == i) DarkBrown else Color(0x33000000), CircleShape)
                            .clickable { onColor(i) }
                    )
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onNote) { Icon(Icons.Filled.Edit, "ملاحظة", tint = Brown) }
                IconButton(onClick = onCopy) { Icon(Icons.Filled.ContentCopy, "نسخ", tint = Brown) }
                if (onDelete != null) {
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "حذف التظليل", tint = Brown) }
                }
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "إغلاق", tint = Brown) }
            }
        }
    }
}

@Composable
fun IndexSheet(
    session: ReaderSession,
    bookmarks: List<Bookmark>,
    onGo: (Int) -> Unit,
    onDeleteBookmark: (Long) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    val outline by produceState<List<OutlineEntry>?>(null) {
        value = try { session.outline() } catch (e: Exception) { emptyList() }
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        TabRow(selectedTabIndex = tab, containerColor = Ivory) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("الفهرس") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("الصفحات") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("الإشارات") })
        }
        when (tab) {
            0 -> {
                val o = outline
                if (o == null) {
                    Text("جارٍ التحميل…", Modifier.padding(16.dp))
                } else if (o.isEmpty()) {
                    Text("لا يحتوي هذا الكتاب على فهرس مدمج. استخدم تبويب «الصفحات» للتنقل السريع.", Modifier.padding(16.dp), color = Brown)
                } else {
                    LazyColumn(Modifier.heightIn(max = 480.dp)) {
                        items(o) { e ->
                            Text(
                                e.title,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable(enabled = e.page >= 0) { onGo(e.page) }
                                    .padding(start = (16 + e.level * 18).dp, end = 16.dp, top = 12.dp, bottom = 12.dp),
                                color = if (e.page >= 0) DarkBrown else Color.Gray
                            )
                        }
                    }
                }
            }
            1 -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(64.dp),
                    modifier = Modifier.heightIn(max = 480.dp).padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items((0 until session.pageCount).toList()) { p ->
                        Box(
                            Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                                .background(Parchment).clickable { onGo(p) }.padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("${p + 1}") }
                    }
                }
            }
            else -> {
                if (bookmarks.isEmpty()) {
                    Text("لا توجد إشارات مرجعية في هذا الكتاب.", Modifier.padding(16.dp), color = Brown)
                } else {
                    LazyColumn(Modifier.heightIn(max = 480.dp)) {
                        items(bookmarks.sortedBy { it.page }, key = { it.id }) { b ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onGo(b.page) }.padding(start = 16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("صفحة ${b.page + 1}  ·  ${formatDate(b.createdAt)}", Modifier.weight(1f))
                                IconButton(onClick = { onDeleteBookmark(b.id) }) { Icon(Icons.Filled.Delete, "حذف", tint = Brown) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchSheet(
    textAvailable: Boolean?,
    query: String,
    onQuery: (String) -> Unit,
    searching: Boolean,
    progress: Int,
    total: Int,
    results: List<SearchHit>,
    onSearch: () -> Unit,
    onPick: (SearchHit) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
        when (textAvailable) {
            false -> Text("هذا الملف مصوّر ولا يحتوي على طبقة نصية، لذلك لا يمكن البحث داخله حالياً.", color = Brown)
            null -> Text("جارٍ فحص الملف…", color = Brown)
            true -> {
                OutlinedTextField(
                    value = query, onValueChange = onQuery,
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("ابحث عن كلمة أو جملة…") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                    trailingIcon = { IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, "بحث") } }
                )
                if (searching) {
                    Text("جارٍ البحث… صفحة $progress من $total", Modifier.padding(top = 8.dp), color = Brown, style = MaterialTheme.typography.bodySmall)
                } else if (query.isNotBlank() && results.isEmpty() && progress > 0) {
                    Text("لا توجد نتائج.", Modifier.padding(top = 8.dp), color = Brown)
                } else if (results.isNotEmpty()) {
                    Text("${results.size} نتيجة", Modifier.padding(top = 8.dp), color = Brown, style = MaterialTheme.typography.bodySmall)
                }
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(results) { r ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(r) }.padding(vertical = 10.dp)) {
                            Text("صفحة ${r.page + 1}", style = MaterialTheme.typography.labelMedium, color = Gold)
                            Text(r.snippet, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReaderSettingsSheet(
    mode: Int,
    onMode: (Int) -> Unit,
    brightness: Float,
    onBrightness: (Float) -> Unit,
    onResetZoom: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
        Text("وضع القراءة", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("نهاري" to 0, "ليلي" to 1, "ورقي" to 2).forEach { (label, m) ->
                FilterChip(selected = mode == m, onClick = { onMode(m) }, label = { Text(label) })
            }
        }
        Text("سطوع القراءة", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("سطوع النظام", Modifier.weight(1f))
            Switch(checked = brightness < 0f, onCheckedChange = { onBrightness(if (it) -1f else 0.6f) })
        }
        if (brightness >= 0f) {
            Slider(value = brightness, onValueChange = onBrightness, valueRange = 0.05f..1f)
        }
        OutlinedButton(onClick = onResetZoom, modifier = Modifier.padding(top = 8.dp)) { Text("إعادة حجم الصفحة") }
    }
}
