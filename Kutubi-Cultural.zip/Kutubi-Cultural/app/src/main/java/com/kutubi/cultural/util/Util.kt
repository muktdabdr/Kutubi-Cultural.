package com.kutubi.cultural.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun coverFile(ctx: Context, id: Long): File {
    val dir = File(ctx.filesDir, "covers")
    dir.mkdirs()
    return File(dir, "$id.jpg")
}

fun formatDate(ms: Long): String =
    DateFormat.getDateInstance(DateFormat.MEDIUM, Locale("ar")).format(Date(ms))
