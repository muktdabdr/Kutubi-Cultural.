package com.kutubi.cultural.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kutubi.cultural.data.Bookmark
import com.kutubi.cultural.ui.AppViewModel
import com.kutubi.cultural.ui.common.EmptyMessage
import com.kutubi.cultural.ui.theme.Brown
import com.kutubi.cultural.ui.theme.Gold
import com.kutubi.cultural.ui.theme.Parchment
import com.kutubi.cultural.util.formatDate

@Composable
fun BookmarksScreen(vm: AppViewModel, onOpen: (Bookmark) -> Unit) {
    val bms by vm.bookmarks.collectAsState()
    val books by vm.books.collectAsState()
    val titles = remember(books) { books.associate { it.id to it.title } }

    Column(Modifier.fillMaxWidth()) {
        Text("الإشارات المرجعية", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp))
        if (bms.isEmpty()) {
            EmptyMessage("لا توجد إشارات مرجعية.\nاضغط أيقونة الإشارة أثناء القراءة لحفظ الصفحة.")
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(bms, key = { it.id }) { b ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(b) },
                        colors = CardDefaults.cardColors(containerColor = Parchment)
                    ) {
                        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Bookmark, null, tint = Gold)
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(titles[b.bookId] ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                                Text("صفحة ${b.page + 1} · ${formatDate(b.createdAt)}", style = MaterialTheme.typography.bodySmall, color = Brown)
                            }
                            IconButton(onClick = { vm.deleteBookmark(b.id) }) { Icon(Icons.Filled.Delete, "حذف", tint = Brown) }
                        }
                    }
                }
            }
        }
    }
}
