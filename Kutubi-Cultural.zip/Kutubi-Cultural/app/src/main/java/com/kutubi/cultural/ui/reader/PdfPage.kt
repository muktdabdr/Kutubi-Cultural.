package com.kutubi.cultural.ui.reader

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.kutubi.cultural.data.HlColors
import com.kutubi.cultural.data.Highlight
import com.kutubi.cultural.pdf.PageText
import com.kutubi.cultural.pdf.ReaderSession
import kotlin.math.roundToInt

data class Sel(val page: Int, val start: Int, val end: Int)

private val InvertMatrix = ColorMatrix(
    floatArrayOf(
        -0.9f, 0f, 0f, 0f, 235f,
        0f, -0.9f, 0f, 0f, 235f,
        0f, 0f, -0.9f, 0f, 235f,
        0f, 0f, 0f, 1f, 0f
    )
)

@Composable
fun PdfPageItem(
    index: Int,
    session: ReaderSession,
    textEnabled: Boolean,
    mode: Int,
    highlights: List<Highlight>,
    sel: Sel?,
    mark: Sel?,
    activeId: Long?,
    onSelect: (Sel) -> Unit,
    onHighlightTap: (Long) -> Unit,
    onBlankTap: () -> Unit,
    onDoubleTap: () -> Unit
) {
    val pw0 = session.pageW(index)
    val ph0 = session.pageH(index)
    val pw = if (pw0 > 0f) pw0 else 595f
    val ph = if (ph0 > 0f) ph0 else 842f

    var widthPx by remember { mutableIntStateOf(0) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var pt by remember { mutableStateOf<PageText?>(null) }
    val renderW = if (widthPx <= 0) 0 else ((widthPx + 31) / 32 * 32).coerceAtMost(2400)

    LaunchedEffect(index, renderW) {
        if (renderW > 0) {
            try { bmp = session.render(index, renderW) } catch (e: Exception) { }
        }
    }
    LaunchedEffect(index, textEnabled) {
        if (textEnabled) {
            try { pt = session.pageText(index) } catch (e: Exception) { }
        }
    }

    val pageHls = remember(highlights, index) { highlights.filter { it.page == index } }
    val hlRects = remember(pt, pageHls) {
        val p = pt
        if (p == null) emptyList<Pair<Highlight, List<Rect>>>()
        else pageHls.map { it to p.rects(it.start, it.end) }
    }
    val selRects = remember(pt, sel) {
        val p = pt
        if (p != null && sel != null && sel.page == index) p.rects(sel.start, sel.end) else emptyList()
    }
    val markRects = remember(pt, mark) {
        val p = pt
        if (p != null && mark != null && mark.page == index) p.rects(mark.start, mark.end) else emptyList()
    }

    val img = remember(bmp) { bmp?.asImageBitmap() }
    val filter = remember(mode) {
        when (mode) {
            1 -> ColorFilter.colorMatrix(InvertMatrix)
            2 -> ColorFilter.tint(Color(0xFFF5E6C4), BlendMode.Modulate)
            else -> null
        }
    }
    val placeholder = when (mode) {
        1 -> Color(0xFF1A1A1A)
        2 -> Color(0xFFF5E6C4)
        else -> Color.White
    }

    val ptNow by rememberUpdatedState(pt)
    val hlNow by rememberUpdatedState(pageHls)
    val selectNow by rememberUpdatedState(onSelect)
    val hlTapNow by rememberUpdatedState(onHighlightTap)
    val blankNow by rememberUpdatedState(onBlankTap)
    val doubleNow by rememberUpdatedState(onDoubleTap)

    Canvas(
        Modifier
            .fillMaxWidth()
            .aspectRatio(pw / ph)
            .onSizeChanged { widthPx = it.width }
            .pointerInput(index) {
                detectTapGestures(
                    onDoubleTap = { doubleNow() },
                    onTap = { off ->
                        val p = ptNow
                        var hit = -1L
                        if (p != null) {
                            val sc = size.width / pw
                            val i = p.hit(off.x / sc, off.y / sc, 4f)
                            if (i >= 0) {
                                val h = hlNow.lastOrNull { it.start <= i && i <= it.end }
                                if (h != null) hit = h.id
                            }
                        }
                        if (hit >= 0) hlTapNow(hit) else blankNow()
                    }
                )
            }
            .pointerInput(index) {
                var aS = 0
                var aE = 0
                var ok = false
                detectDragGesturesAfterLongPress(
                    onDragStart = { off ->
                        ok = false
                        val p = ptNow
                        if (p != null) {
                            val sc = size.width / pw
                            val i = p.hit(off.x / sc, off.y / sc, 16f)
                            if (i >= 0) {
                                aS = p.wordStart(i)
                                aE = p.wordEnd(i)
                                ok = true
                                selectNow(Sel(index, aS, aE))
                            }
                        }
                    },
                    onDrag = { change, _ ->
                        val p = ptNow
                        if (ok && p != null) {
                            change.consume()
                            val sc = size.width / pw
                            val i = p.hit(change.position.x / sc, change.position.y / sc, 60f)
                            if (i >= 0) {
                                val s: Int
                                val e: Int
                                if (i >= aE) { s = aS; e = p.wordEnd(i) }
                                else if (i <= aS) { s = p.wordStart(i); e = aE }
                                else { s = aS; e = aE }
                                selectNow(Sel(index, s, e))
                            }
                        }
                    },
                    onDragEnd = { },
                    onDragCancel = { }
                )
            }
    ) {
        val sc = size.width / pw
        if (img != null) {
            drawImage(
                img,
                dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                colorFilter = filter,
                filterQuality = FilterQuality.Medium
            )
        } else {
            drawRect(placeholder)
        }
        val alpha = if (mode == 1) 0.55f else 0.45f
        for ((h, rs) in hlRects) {
            val col = HlColors.argb[h.color.coerceIn(0, 3)].copy(alpha = alpha)
            for (r in rs) {
                drawRect(col, Offset(r.left * sc, r.top * sc), Size(r.width * sc, r.height * sc))
                if (h.id == activeId) {
                    drawRect(
                        Color(0xFF5B3A29), Offset(r.left * sc, r.top * sc),
                        Size(r.width * sc, r.height * sc), style = Stroke(width = 2f)
                    )
                }
            }
        }
        for (r in selRects) {
            drawRect(Color(0x663D8BFD), Offset(r.left * sc, r.top * sc), Size(r.width * sc, r.height * sc))
        }
        for (r in markRects) {
            drawRect(Color(0x77FF9800), Offset(r.left * sc, r.top * sc), Size(r.width * sc, r.height * sc))
        }
    }
}
