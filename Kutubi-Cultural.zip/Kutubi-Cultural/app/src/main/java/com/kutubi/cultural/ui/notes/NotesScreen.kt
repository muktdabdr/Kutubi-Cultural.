package com.kutubi.cultural.ui.notes

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import com.kutubi.cultural.data.HlColors
import com.kutubi.cultural.data.Highlight
import com.kutubi.cultural.ui.AppViewModel
import com.kutubi.cultural.ui.common.ConfirmDialog
import com.kutubi.cultural.ui.common.EmptyMessage
import com.kutubi.cultural.ui.common.NoteDialog
import com.kutubi.cultural.ui.theme.Brown
import com.kutubi.cultural.ui.theme.Parchment
import com.kutubi.cultural.util.formatDate

@Composable
fun NotesScreen(vm: AppViewModel, onOpen: (Highlight) -> Unit) {
    val hls by vm.highlights.collectAsState()
    val books by vm.books.collectAsState()
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var filter by remember { mutableIntStateOf(-1) }
    var editing by remember { mutableStateOf<Highlight?>(null) }
    var deleting by remember { mutableStateOf<Highlight?>(null) }
    val titles = remember(books) { books.associate { it.id to it.title } }
    val list = remember(hls, filter) { hls.filter { filter < 0 || it.color == filter }.sortedByDescending { it.createdAt } }

    fun copy(text: String) {
        clipboard.setText(AnnotatedString(text))
        Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("ملاحظاتي", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            if (list.isNotEmpty()) {
                IconButton(onClick = {
                    copy(list.joinToString("\n\n") { h ->
                        "«${h.text}»" + (if (h.note.isNotBlank()) "\nملاحظة: ${h.note}" else "") +
                            "\n— ${titles[h.bookId] ?: ""}، ص ${h.page + 1}"
                    })
                }) { Icon(Icons.Filled.ContentCopy, "نسخ كل الاقتباسات", tint = Brown) }
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = filter < 0, onClick = { filter = -1 }, label = { Text("الكل") })
            for (i in 0 until 4) {
                FilterChip(
                    selected = filter == i, onClick = { filter = i },
                    label = { Text(HlColors.names[i]) },
                    leadingIcon = { Box(Modifier.size(14.dp).background(HlColors.argb[i], CircleShape)) }
                )
            }
        }
        if (list.isEmpty()) {
            EmptyMessage("لا توجد تظليلات بعد.\nحدّد نصاً أثناء القراءة (بالضغط المطوّل) لتظليله وإضافة ملاحظة.")
        } else {
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { h ->
                    HighlightCard(
                        h = h, title = titles[h.bookId] ?: "",
                        onOpen = { onOpen(h) },
                        onEdit = { editing = h },
                        onColor = { c -> vm.setColor(h.id, c) },
                        onCopy = { copy(h.text) },
                        onDelete = { deleting = h }
                    )
                }
            }
        }
    }

    editing?.let { h ->
        NoteDialog(h.text, h.note, onSave = { vm.setNote(h.id, it); editing = null }, onDismiss = { editing = null })
    }
    deleting?.let { h ->
        ConfirmDialog("حذف التظليل", "سيُحذف التظليل وملاحظته. لن يتغيّر ملف PDF.", "حذف",
            onConfirm = { vm.deleteHighlight(h.id); deleting = null }, onDismiss = { deleting = null })
    }
}

@Composable
private fun HighlightCard(
    h: Highlight, title: String,
    onOpen: () -> Unit, onEdit: () -> Unit, onColor: (Int) -> Unit, onCopy: () -> Unit, onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = Parchment)
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(6.dp).fillMaxHeight().background(HlColors.argb[h.color.coerceIn(0, 3)]))
            Column(Modifier.padding(12.dp).weight(1f)) {
                Text(h.text, style = MaterialTheme.typography.bodyMedium)
                if (h.note.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(h.note, style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic, color = Brown)
                }
                Spacer(Modifier.height(6.dp))
                Text("$title · ص ${h.page + 1} · ${formatDate(h.createdAt)}", style = MaterialTheme.typography.labelSmall, color = Brown)
                Row {
                    IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "ملاحظة", tint = Brown) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.Palette, "لون", tint = Brown) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            for (i in 0 until 4) {
                                DropdownMenuItem(
                                    text = { Text(HlColors.names[i]) },
                                    leadingIcon = { Box(Modifier.size(16.dp).background(HlColors.argb[i], CircleShape)) },
                                    onClick = { onColor(i); menu = false }
                                )
                            }
                        }
                    }
                    IconButton(onClick = onCopy) { Icon(Icons.Filled.ContentCopy, "نسخ", tint = Brown) }
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "حذف", tint = Brown) }
                }
            }
        }
    }
}
