package com.kutubi.cultural

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavHostController
import androidx.navigation.navArgument
import com.kutubi.cultural.ui.AppViewModel
import com.kutubi.cultural.ui.library.BookmarksScreen
import com.kutubi.cultural.ui.library.LibraryScreen
import com.kutubi.cultural.ui.notes.NotesScreen
import com.kutubi.cultural.ui.reader.ReaderScreen
import com.kutubi.cultural.ui.theme.Ivory
import com.kutubi.cultural.ui.theme.KutubiTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private val pending = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent {
            KutubiTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot(vm, pending)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) i.data?.let { pending.value = it }
    }
}

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo("library") { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun AppRoot(vm: AppViewModel, pending: MutableState<Uri?>) {
    val nav = rememberNavController()
    val ctx = LocalContext.current

    LaunchedEffect(Unit) {
        vm.messages.collect { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
    }
    val uri = pending.value
    LaunchedEffect(uri) {
        if (uri != null) {
            pending.value = null
            val id = vm.importUri(uri)
            if (id != null) nav.navigate("reader/$id")
        }
    }

    val tabs = listOf(
        Tab("library", "المكتبة", Icons.Filled.MenuBook),
        Tab("bookmarks", "الإشارات", Icons.Filled.Bookmark),
        Tab("notes", "ملاحظاتي", Icons.Filled.FormatQuote)
    )
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    Scaffold(
        containerColor = Ivory,
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar(containerColor = Ivory) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = { nav.goTab(t.route) },
                            icon = { Icon(t.icon, null) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "library", modifier = Modifier.padding(pad)) {
            composable("library") {
                LibraryScreen(
                    vm,
                    onOpen = { nav.navigate("reader/$it") },
                    onGoBookmarks = { nav.goTab("bookmarks") },
                    onGoNotes = { nav.goTab("notes") }
                )
            }
            composable("bookmarks") {
                BookmarksScreen(vm) { nav.navigate("reader/${it.bookId}?page=${it.page}") }
            }
            composable("notes") {
                NotesScreen(vm) { nav.navigate("reader/${it.bookId}?page=${it.page}&hl=${it.id}") }
            }
            composable(
                "reader/{id}?page={page}&hl={hl}",
                arguments = listOf(
                    navArgument("id") { type = NavType.LongType },
                    navArgument("page") { type = NavType.IntType; defaultValue = -1 },
                    navArgument("hl") { type = NavType.LongType; defaultValue = -1L }
                )
            ) { e ->
                ReaderScreen(
                    vm = vm,
                    bookId = e.arguments?.getLong("id") ?: -1L,
                    startPage = e.arguments?.getInt("page") ?: -1,
                    focusHl = e.arguments?.getLong("hl") ?: -1L,
                    onBack = { nav.popBackStack() }
                )
            }
        }
    }
}
