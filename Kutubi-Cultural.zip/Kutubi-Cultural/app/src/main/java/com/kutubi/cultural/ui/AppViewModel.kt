package com.kutubi.cultural.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kutubi.cultural.data.Book
import com.kutubi.cultural.data.Bookmark
import com.kutubi.cultural.data.Db
import com.kutubi.cultural.data.Highlight
import com.kutubi.cultural.data.Repository
import com.kutubi.cultural.util.SettingsStore
import com.kutubi.cultural.util.coverFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class AppViewModel(private val app: Application) : AndroidViewModel(app) {
    private val repo = Repository(Db(app))
    val settings = SettingsStore(app)

    val books = MutableStateFlow<List<Book>>(emptyList())
    val highlights = MutableStateFlow<List<Highlight>>(emptyList())
    val bookmarks = MutableStateFlow<List<Bookmark>>(emptyList())
    val importing = MutableStateFlow(false)
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    init {
        viewModelScope.launch { reload() }
    }

    private suspend fun reload() {
        val data = withContext(Dispatchers.IO) { Triple(repo.books(), repo.highlights(), repo.bookmarks()) }
        books.value = data.first
        highlights.value = data.second
        bookmarks.value = data.third
    }

    // ---------- الكتب ----------
    fun importMany(uris: List<Uri>) {
        viewModelScope.launch {
            importing.value = true
            var ok = 0
            for (u in uris) if (importUri(u) != null) ok++
            importing.value = false
            if (ok > 0) messages.tryEmit(if (ok == 1) "تمت إضافة الكتاب إلى مكتبتك" else "تمت إضافة $ok كتب إلى مكتبتك")
        }
    }

    /** ينسخ الملف إلى تخزين التطبيق ويضيفه للمكتبة. الملف الأصلي لا يُعدَّل أبداً. */
    suspend fun importUri(uri: Uri): Long? {
        val result = withContext(Dispatchers.IO) {
            val cr = app.contentResolver
            var name = uri.lastPathSegment?.substringAfterLast('/') ?: "كتاب"
            var size = -1L
            try {
                cr.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
            } catch (e: Exception) { }
            val title = name.removeSuffix(".pdf").removeSuffix(".PDF")
            val existing = books.value.firstOrNull { it.title == title && size > 0 && File(it.path).length() == size }
            if (existing != null) return@withContext existing.id

            val dir = File(app.filesDir, "books")
            dir.mkdirs()
            val dest = File(dir, UUID.randomUUID().toString() + ".pdf")
            try {
                val input = cr.openInputStream(uri) ?: throw IllegalStateException("no stream")
                input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                val pages = countPages(dest)
                if (pages <= 0) throw IllegalStateException("empty")
                val id = repo.insertBook(title, dest.absolutePath, pages)
                makeCover(dest, coverFile(app, id))
                id
            } catch (e: Exception) {
                dest.delete()
                null
            }
        }
        if (result == null) {
            messages.tryEmit("تعذّر فتح الملف. قد يكون تالفاً أو محمياً بكلمة مرور")
            return null
        }
        reload()
        return result
    }

    private fun countPages(file: File): Int {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val r = PdfRenderer(pfd)
            try { return r.pageCount } finally { r.close() }
        } finally {
            pfd.close()
        }
    }

    private fun makeCover(file: File, out: File) {
        try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val r = PdfRenderer(pfd)
                try {
                    val p = r.openPage(0)
                    val w = 360
                    val h = (w * p.height.toFloat() / p.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    p.close()
                    out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                    bmp.recycle()
                } finally { r.close() }
            } finally { pfd.close() }
        } catch (e: Exception) { }
    }

    fun deleteBook(b: Book) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repo.deleteBook(b.id)
                File(b.path).delete()
                coverFile(app, b.id).delete()
            }
            reload()
        }
    }

    fun saveProgress(id: Long, page: Int) {
        val now = System.currentTimeMillis()
        books.value = books.value.map { if (it.id == id) it.copy(lastPage = page, lastOpened = now) else it }
        viewModelScope.launch { withContext(Dispatchers.IO) { repo.saveProgress(id, page) } }
    }

    // ---------- التظليل والملاحظات ----------
    suspend fun createHighlight(bookId: Long, page: Int, start: Int, end: Int, text: String, color: Int): Long {
        val id = withContext(Dispatchers.IO) { repo.insertHighlight(bookId, page, start, end, text, color) }
        reload()
        return id
    }

    fun setNote(id: Long, note: String) = mutate { repo.setNote(id, note) }
    fun setColor(id: Long, color: Int) = mutate { repo.setColor(id, color) }
    fun deleteHighlight(id: Long) = mutate { repo.deleteHighlight(id) }

    // ---------- الإشارات المرجعية ----------
    fun addBookmark(bookId: Long, page: Int) {
        if (bookmarks.value.any { it.bookId == bookId && it.page == page }) return
        mutate { repo.addBookmark(bookId, page) }
    }

    fun deleteBookmark(id: Long) = mutate { repo.deleteBookmark(id) }

    private fun mutate(block: () -> Unit) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { block() }
            reload()
        }
    }
}
