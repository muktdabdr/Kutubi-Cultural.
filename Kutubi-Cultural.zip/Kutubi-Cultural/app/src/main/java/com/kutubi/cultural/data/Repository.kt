package com.kutubi.cultural.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "kutubi.db", null, 1) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, " +
                "path TEXT NOT NULL, pages INTEGER NOT NULL, lastPage INTEGER NOT NULL DEFAULT 0, " +
                "lastOpened INTEGER NOT NULL DEFAULT 0, addedAt INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE highlights(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "bookId INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE, page INTEGER NOT NULL, " +
                "startIdx INTEGER NOT NULL, endIdx INTEGER NOT NULL, text TEXT NOT NULL, " +
                "color INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', createdAt INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "bookId INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE, " +
                "page INTEGER NOT NULL, createdAt INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_hl_book ON highlights(bookId, page)")
        db.execSQL("CREATE INDEX idx_bm_book ON bookmarks(bookId)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

class Repository(private val db: Db) {

    fun books(): List<Book> {
        val out = ArrayList<Book>()
        db.readableDatabase.rawQuery(
            "SELECT id,title,path,pages,lastPage,lastOpened,addedAt FROM books ORDER BY addedAt DESC", null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Book(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getInt(4), c.getLong(5), c.getLong(6)))
            }
        }
        return out
    }

    fun insertBook(title: String, path: String, pages: Int): Long {
        val v = ContentValues().apply {
            put("title", title); put("path", path); put("pages", pages)
            put("lastPage", 0); put("lastOpened", 0L); put("addedAt", System.currentTimeMillis())
        }
        return db.writableDatabase.insertOrThrow("books", null, v)
    }

    fun saveProgress(id: Long, page: Int) {
        val v = ContentValues().apply { put("lastPage", page); put("lastOpened", System.currentTimeMillis()) }
        db.writableDatabase.update("books", v, "id=?", arrayOf(id.toString()))
    }

    fun deleteBook(id: Long) {
        db.writableDatabase.delete("books", "id=?", arrayOf(id.toString()))
    }

    fun highlights(): List<Highlight> {
        val out = ArrayList<Highlight>()
        db.readableDatabase.rawQuery(
            "SELECT id,bookId,page,startIdx,endIdx,text,color,note,createdAt FROM highlights ORDER BY createdAt DESC", null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Highlight(c.getLong(0), c.getLong(1), c.getInt(2), c.getInt(3), c.getInt(4),
                        c.getString(5), c.getInt(6), c.getString(7), c.getLong(8))
                )
            }
        }
        return out
    }

    fun insertHighlight(bookId: Long, page: Int, start: Int, end: Int, text: String, color: Int): Long {
        val v = ContentValues().apply {
            put("bookId", bookId); put("page", page); put("startIdx", start); put("endIdx", end)
            put("text", text); put("color", color); put("note", ""); put("createdAt", System.currentTimeMillis())
        }
        return db.writableDatabase.insertOrThrow("highlights", null, v)
    }

    fun setNote(id: Long, note: String) {
        db.writableDatabase.update("highlights", ContentValues().apply { put("note", note) }, "id=?", arrayOf(id.toString()))
    }

    fun setColor(id: Long, color: Int) {
        db.writableDatabase.update("highlights", ContentValues().apply { put("color", color) }, "id=?", arrayOf(id.toString()))
    }

    fun deleteHighlight(id: Long) {
        db.writableDatabase.delete("highlights", "id=?", arrayOf(id.toString()))
    }

    fun bookmarks(): List<Bookmark> {
        val out = ArrayList<Bookmark>()
        db.readableDatabase.rawQuery(
            "SELECT id,bookId,page,createdAt FROM bookmarks ORDER BY createdAt DESC", null
        ).use { c ->
            while (c.moveToNext()) out.add(Bookmark(c.getLong(0), c.getLong(1), c.getInt(2), c.getLong(3)))
        }
        return out
    }

    fun addBookmark(bookId: Long, page: Int): Long {
        val v = ContentValues().apply { put("bookId", bookId); put("page", page); put("createdAt", System.currentTimeMillis()) }
        return db.writableDatabase.insertOrThrow("bookmarks", null, v)
    }

    fun deleteBookmark(id: Long) {
        db.writableDatabase.delete("bookmarks", "id=?", arrayOf(id.toString()))
    }
}
