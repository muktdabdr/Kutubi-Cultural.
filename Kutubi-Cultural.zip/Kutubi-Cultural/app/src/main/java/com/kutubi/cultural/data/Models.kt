package com.kutubi.cultural.data

import androidx.compose.ui.graphics.Color

data class Book(
    val id: Long,
    val title: String,
    val path: String,
    val pages: Int,
    val lastPage: Int,
    val lastOpened: Long,
    val addedAt: Long
)

data class Highlight(
    val id: Long,
    val bookId: Long,
    val page: Int,
    val start: Int,
    val end: Int,
    val text: String,
    val color: Int,
    val note: String,
    val createdAt: Long
)

data class Bookmark(val id: Long, val bookId: Long, val page: Int, val createdAt: Long)

object HlColors {
    val argb = listOf(Color(0xFFFFD93B), Color(0xFF6FCF97), Color(0xFF56CCF2), Color(0xFFFF8FB1))
    val names = listOf("أصفر", "أخضر", "أزرق", "وردي")
}
