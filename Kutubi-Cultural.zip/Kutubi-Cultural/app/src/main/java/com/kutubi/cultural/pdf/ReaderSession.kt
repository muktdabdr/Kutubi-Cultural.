package com.kutubi.cultural.pdf

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineNode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

class OutlineEntry(val title: String, val page: Int, val level: Int)
class SearchHit(val page: Int, val start: Int, val end: Int, val snippet: String)

/** جلسة قراءة واحدة: العرض عبر PdfRenderer، واستخراج النص عبر PDFBox. */
class ReaderSession(private val file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    val pageCount: Int = renderer.pageCount

    private val renderLock = Mutex()
    private val textLock = Mutex()
    private var doc: PDDocument? = null
    private var sizes = FloatArray(0)

    private val bitmaps = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6).toInt().coerceAtLeast(24 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val texts = LruCache<Int, PageText>(10)

    fun pageW(i: Int): Float = if (2 * i < sizes.size) sizes[2 * i] else 0f
    fun pageH(i: Int): Float = if (2 * i + 1 < sizes.size) sizes[2 * i + 1] else 0f

    suspend fun loadSizes(): FloatArray = withContext(Dispatchers.IO) {
        val arr = FloatArray(pageCount * 2)
        renderLock.withLock {
            for (i in 0 until pageCount) {
                val p = renderer.openPage(i)
                arr[2 * i] = p.width.toFloat()
                arr[2 * i + 1] = p.height.toFloat()
                p.close()
            }
        }
        sizes = arr
        arr
    }

    suspend fun render(index: Int, widthPx: Int): Bitmap {
        val key = "$index:$widthPx"
        bitmaps.get(key)?.let { return it }
        val bmp = withContext(Dispatchers.IO) {
            renderLock.withLock {
                val page = renderer.openPage(index)
                try {
                    val h = (widthPx * page.height.toFloat() / page.width).toInt().coerceAtLeast(1)
                    val b = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    b.eraseColor(android.graphics.Color.WHITE)
                    page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    b
                } finally {
                    page.close()
                }
            }
        }
        bitmaps.put(key, bmp)
        return bmp
    }

    suspend fun pageText(index: Int): PageText {
        texts.get(index)?.let { return it }
        val pt = withContext(Dispatchers.IO) {
            textLock.withLock {
                val d = doc ?: PDDocument.load(file).also { doc = it }
                extractPage(d, index)
            }
        }
        texts.put(index, pt)
        return pt
    }

    /** هل يحتوي الملف على طبقة نصية قابلة للاستخراج؟ (فحص عيّنة من الصفحات) */
    suspend fun detectText(): Boolean {
        val idx = (0 until minOf(pageCount, 6)).toMutableList()
        listOf(pageCount / 3, pageCount / 2, pageCount * 2 / 3).forEach {
            if (it in 0 until pageCount && it !in idx) idx.add(it)
        }
        for (i in idx) {
            val t = try { pageText(i) } catch (e: Exception) { null }
            if (t != null && t.chars.count { !it.virtual } >= 5) return true
        }
        return false
    }

    suspend fun outline(): List<OutlineEntry> = withContext(Dispatchers.IO) {
        textLock.withLock {
            val d = doc ?: PDDocument.load(file).also { doc = it }
            val res = ArrayList<OutlineEntry>()
            val root = d.documentCatalog.documentOutline
            if (root != null) {
                fun walk(node: PDOutlineNode, level: Int) {
                    var cur: PDOutlineItem? = node.firstChild
                    while (cur != null) {
                        var page = -1
                        try {
                            val p = cur.findDestinationPage(d)
                            if (p != null) page = d.pages.indexOf(p)
                        } catch (e: Exception) { }
                        res.add(OutlineEntry(cur.title ?: "", page, level))
                        walk(cur, level + 1)
                        cur = cur.nextSibling
                    }
                }
                walk(root, 0)
            }
            res
        }
    }

    suspend fun search(query: String, onProgress: (Int) -> Unit, onHit: (SearchHit) -> Unit) {
        val q = foldQuery(query)
        if (q.isEmpty()) return
        var total = 0
        for (i in 0 until pageCount) {
            currentCoroutineContext().ensureActive()
            onProgress(i + 1)
            val pt = (try { pageText(i) } catch (e: Exception) { null }) ?: continue
            val sb = StringBuilder()
            val map = ArrayList<Int>()
            pt.chars.forEachIndexed { ci, c ->
                if (c.virtual) {
                    if (sb.isNotEmpty() && sb[sb.length - 1] != ' ') { sb.append(' '); map.add(ci) }
                } else {
                    for (ch in c.text) {
                        val f = foldChar(ch) ?: continue
                        if (f == ' ' && sb.isNotEmpty() && sb[sb.length - 1] == ' ') continue
                        sb.append(f); map.add(ci)
                    }
                }
            }
            val s = sb.toString()
            var from = 0
            while (true) {
                val m = s.indexOf(q, from)
                if (m < 0) break
                val snippet = s.substring(maxOf(0, m - 30), minOf(s.length, m + q.length + 40)).trim()
                onHit(SearchHit(i, map[m], map[m + q.length - 1], snippet))
                total++
                if (total >= 300) return
                from = m + q.length
            }
        }
    }

    fun close() {
        try { renderer.close() } catch (e: Exception) { }
        try { pfd.close() } catch (e: Exception) { }
        try { doc?.close() } catch (e: Exception) { }
    }
}
