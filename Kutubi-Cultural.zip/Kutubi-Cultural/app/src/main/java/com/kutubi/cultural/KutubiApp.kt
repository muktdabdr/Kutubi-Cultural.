package com.kutubi.cultural

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class KutubiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(applicationContext)
    }
}
