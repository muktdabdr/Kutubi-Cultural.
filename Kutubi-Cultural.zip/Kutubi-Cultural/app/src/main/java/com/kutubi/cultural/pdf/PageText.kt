package com.kutubi.cultural.pdf

import androidx.compose.ui.geometry.Rect
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** حرف واحد في الطبقة النصية، بإحداثيات بوحدات PDF (نقاط) من أعلى يسار الصفحة. */
class PChar(
    val text: String,
    val l: Float, val t: Float, val r: Float, val b: Float,
    val line: Int,
    val wordStart: Boolean,
    val virtual: Boolean
)

class PageText(val width: Float, val height: Float, val chars: List<PChar>) {

    val isEmpty: Boolean get() = chars.none { !it.virtual }

    fun hit(x: Float, y: Float, tol: Float): Int {
        var best = -1
        var bd = Float.MAX_VALUE
        for (i in chars.indices) {
            val c = chars[i]
            if (c.virtual) continue
            val dx = when {
                x < c.l -> c.l - x
                x > c.r -> x - c.r
                else -> 0f
            }
            val dy = when {
                y < c.t -> c.t - y
                y > c.b -> y - c.b
                else -> 0f
            }
            val d = dx * dx + dy * dy
            if (d < bd) { bd = d; best = i }
        }
        return if (best >= 0 && bd <= tol * tol) best else -1
    }

    fun wordStart(i: Int): Int {
        var s = i
        while (s > 0 && !chars[s].wordStart) s--
        return s
    }

    fun wordEnd(i: Int): Int {
        var e = i
        while (e + 1 < chars.size && !chars[e + 1].wordStart) e++
        return e
    }

    fun textOf(s: Int, e: Int): String {
        if (chars.isEmpty()) return ""
        val sb = StringBuilder()
        for (i in s.coerceAtLeast(0)..e.coerceAtMost(chars.size - 1)) {
            val c = chars[i]
            if (c.virtual) {
                if (sb.isNotEmpty() && sb[sb.length - 1] != ' ') sb.append(' ')
            } else sb.append(c.text)
        }
        return sb.toString().trim()
    }

    fun rects(s: Int, e: Int): List<Rect> {
        val out = ArrayList<Rect>()
        if (chars.isEmpty()) return out
        val a = s.coerceIn(0, chars.size - 1)
        val b = e.coerceIn(a, chars.size - 1)
        var curLine = -1
        var l = 0f; var t = 0f; var r = 0f; var bt = 0f
        for (i in a..b) {
            val c = chars[i]
            if (c.virtual) continue
            if (c.line != curLine) {
                if (curLine >= 0) out.add(Rect(l, t, r, bt))
                curLine = c.line
                l = c.l; t = c.t; r = c.r; bt = c.b
            } else {
                l = min(l, c.l); t = min(t, c.t); r = max(r, c.r); bt = max(bt, c.b)
            }
        }
        if (curLine >= 0) out.add(Rect(l, t, r, bt))
        return out
    }
}

private class Extractor : PDFTextStripper() {
    val chars = ArrayList<PChar>()
    var pw = 0f
    var ph = 0f
    private var line = -1
    private var lastY = -1e9f
    private var lastH = 1f

    override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
        if (textPositions.isEmpty()) return
        var first = true
        for (tp in textPositions) {
            val u = Normalizer.normalize(tp.unicode ?: "", Normalizer.Form.NFKC)
            if (u.isEmpty()) continue
            pw = tp.pageWidth
            ph = tp.pageHeight
            val h = tp.heightDir.coerceAtLeast(1f)
            val y = tp.yDirAdj
            if (first) {
                if (chars.isNotEmpty()) {
                    chars.add(PChar(" ", 0f, 0f, 0f, 0f, line, true, true))
                }
                if (line < 0 || abs(y - lastY) > lastH * 0.6f) line++
                lastY = y
                lastH = h
            }
            val l = tp.xDirAdj
            val r = max(l + tp.widthDirAdj, l + 0.5f)
            chars.add(PChar(u, l, y - h, r, y + h * 0.25f, line, first, false))
            first = false
        }
    }
}

fun extractPage(doc: PDDocument, index: Int): PageText {
    val ex = Extractor()
    ex.startPage = index + 1
    ex.endPage = index + 1
    ex.getText(doc)
    return PageText(ex.pw, ex.ph, ex.chars)
}

internal fun foldChar(c: Char): Char? = when {
    c in '\u064B'..'\u0652' || c == '\u0640' || c == '\u0670' -> null
    c == 'أ' || c == 'إ' || c == 'آ' -> 'ا'
    c == 'ى' -> 'ي'
    c.isWhitespace() -> ' '
    else -> c.lowercaseChar()
}

internal fun foldQuery(s: String): String = buildString {
    for (ch in Normalizer.normalize(s, Normalizer.Form.NFKC)) {
        val f = foldChar(ch) ?: continue
        if (f == ' ' && isNotEmpty() && this[length - 1] == ' ') continue
        append(f)
    }
}.trim()
