package com.kutubi.cultural.ui.library

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kutubi.cultural.data.Book
import com.kutubi.cultural.ui.AppViewModel
import com.kutubi.cultural.ui.common.BookCover
import com.kutubi.cultural.ui.common.ConfirmDialog
import com.kutubi.cultural.ui.theme.Brown
import com.kutubi.cultural.ui.theme.DarkBrown
import com.kutubi.cultural.ui.theme.Gold
import com.kutubi.cultural.ui.theme.Ivory
import com.kutubi.cultural.ui.theme.Parchment

@Composable
fun LibraryScreen(
    vm: AppViewModel,
    onOpen: (Long) -> Unit,
    onGoBookmarks: () -> Unit,
    onGoNotes: () -> Unit
) {
    val books by vm.books.collectAsState()
    val hls by vm.highlights.collectAsState()
    val bms by vm.bookmarks.collectAsState()
    val importing by vm.importing.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importMany(uris)
    }
    val addBook = { picker.launch(arrayOf("application/pdf")) }
    var toDelete by remember { mutableStateOf<Book?>(null) }
    val recent = remember(books) { books.filter { it.lastOpened > 0 }.sortedByDescending { it.lastOpened }.take(10) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
            item { Header() }
            if (importing) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold) }
            item {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(Icons.Filled.Bookmark, "الإشارات المرجعية", bms.size, Modifier.weight(1f), onGoBookmarks)
                    StatCard(Icons.Filled.FormatQuote, "التظليلات والملاحظات", hls.size, Modifier.weight(1f), onGoNotes)
                }
            }
            if (books.isEmpty()) {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Filled.MenuBook, null, tint = Gold, modifier = Modifier.size(72.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("مكتبتك فارغة", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(4.dp))
                        Text("أضف أول كتاب PDF لتبدأ رحلة القراءة.", color = Brown)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { addBook() }) { Text("إضافة كتاب PDF") }
                    }
                }
            } else {
                item { SectionTitle("آخر ما قرأت") }
                if (recent.isEmpty()) {
                    item { Text("لم تبدأ القراءة بعد. افتح أي كتاب ليظهر هنا.", Modifier.padding(horizontal = 16.dp), color = Brown) }
                } else {
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(recent, key = { it.id }) { b -> RecentCard(b) { onOpen(b.id) } }
                        }
                    }
                }
                item { SectionTitle("الكتب المحفوظة (${books.size})") }
                items(books, key = { it.id }) { b ->
                    BookRow(b, onClick = { onOpen(b.id) }, onDelete = { toDelete = b })
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { addBook() },
            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp),
            containerColor = Gold, contentColor = DarkBrown,
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("إضافة كتاب PDF") }
        )
    }

    toDelete?.let { b ->
        ConfirmDialog(
            title = "حذف من المكتبة",
            message = "سيُحذف «${b.title}» من التطبيق مع تظليلاته وملاحظاته وإشاراته. الملف الأصلي في هاتفك لن يُحذف.",
            confirmLabel = "حذف",
            onConfirm = { vm.deleteBook(b); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
}

@Composable
private fun Header() {
    Box(
        Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(DarkBrown, Brown)))
    ) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            Text("مقتدى", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).background(Gold, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.MenuBook, null, tint = DarkBrown, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("كتبي", color = Ivory, fontSize = 30.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Text("Kutubi Cultural", color = Gold, fontSize = 13.sp, letterSpacing = 2.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text, style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp)
    )
}

@Composable
private fun StatCard(icon: ImageVector, label: String, count: Int, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Parchment)
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Gold)
            Text("$count", fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
            Text(label, style = MaterialTheme.typography.bodySmall, color = Brown)
        }
    }
}

private fun progressOf(b: Book): Float =
    if (b.pages <= 1) 0f else ((b.lastPage + 1).toFloat() / b.pages).coerceIn(0f, 1f)

@Composable
private fun RecentCard(b: Book, onClick: () -> Unit) {
    Column(Modifier.width(120.dp).clickable(onClick = onClick)) {
        BookCover(b, Modifier.width(120.dp).height(168.dp))
        Spacer(Modifier.height(6.dp))
        Text(b.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        val p = progressOf(b)
        LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Parchment)
    }
}

@Composable
private fun BookRow(b: Book, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Parchment)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            BookCover(b, Modifier.size(width = 64.dp, height = 90.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(b.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text("${b.pages} صفحة", style = MaterialTheme.typography.bodySmall, color = Brown)
                if (b.lastOpened > 0) {
                    Text("وصلت إلى صفحة ${b.lastPage + 1}", style = MaterialTheme.typography.bodySmall, color = Brown)
                    Spacer(Modifier.height(6.dp))
                    val p = progressOf(b)
                    LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Ivory)
                }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "حذف", tint = Brown) }
        }
    }
}
