package com.kutubi.cultural.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

val Ivory = Color(0xFFFBF5E6)
val Parchment = Color(0xFFF3E9CF)
val Brown = Color(0xFF5B3A29)
val DarkBrown = Color(0xFF3E2618)
val Gold = Color(0xFFC9A24B)

private val Scheme = lightColorScheme(
    primary = Brown,
    onPrimary = Ivory,
    primaryContainer = Parchment,
    onPrimaryContainer = DarkBrown,
    secondary = Gold,
    onSecondary = DarkBrown,
    secondaryContainer = Color(0xFFEBD9A8),
    onSecondaryContainer = DarkBrown,
    background = Ivory,
    onBackground = DarkBrown,
    surface = Ivory,
    onSurface = DarkBrown,
    surfaceVariant = Parchment,
    onSurfaceVariant = Brown,
    outline = Color(0xFFB89B6A)
)

private val Base = Typography()
private val KTypography = Typography(
    headlineMedium = Base.headlineMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold),
    headlineSmall = Base.headlineSmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold),
    titleLarge = Base.titleLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold),
    titleMedium = Base.titleMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
)

@Composable
fun KutubiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = KTypography, content = content)
}
